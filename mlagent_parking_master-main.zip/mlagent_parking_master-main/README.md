# Autonomous Parking using the Unity ML-Agents Toolkit

Training autonomous cars to park in Unity using the ML-Agents Toolkit.

Some of the 3D models used in this project are from Sketchfab:

- [Shrine of The Fury](https://sketchfab.com/3d-models/chevrolet-corvette-1980-different-colours-7e428bdb3ab54b4e9ac610e545fd9d03)

- [louieoliva](https://sketchfab.com/3d-models/low-poly-tree-pack-ea6e844754da494a9c38501b4fff92ad)